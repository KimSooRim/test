package com.mbcit.s20250401_1_springBoot_JPA01;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
//	@Controller
//	@RestController : RESTful에서 사용하는 어노테이션 @Controller와 @ResponseBody를 합친 형태.
//	=> @RestController 어노테이션이 붙은 클래스의 모든 메서드가 JSON 또는 기타 객체 형태로 HTTP 응답을 처리한다.
@RestController
public class HomeController {
	
//	@RequestMapping("/")
//	public @ResponseBody String home() {
//		log.info("springBoot JPA");
//		
//		return "springBoot JPA";
	
	@GetMapping("/")
	public String home() {
		log.info("springBoot JPA");
		return "springBoot JPA";
	}

}
