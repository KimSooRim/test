package com.mbcit.s20250401_1_springBoot_JPA01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S202504011SpringBootJpa01Application {

	public static void main(String[] args) {
		SpringApplication.run(S202504011SpringBootJpa01Application.class, args);
	}

}
