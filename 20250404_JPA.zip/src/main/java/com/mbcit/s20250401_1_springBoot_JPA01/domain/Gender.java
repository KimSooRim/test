package com.mbcit.s20250401_1_springBoot_JPA01.domain;

//	enum : 열거형, 자바에서 여러개의 상수 값을 묶어 관리할 수 있는 데이터 타입
//	=> 특정한 값들의 집합을 정의한다.
public enum Gender {
	BABY,
	MALE, // 0
	FEMALE	// 1

}
