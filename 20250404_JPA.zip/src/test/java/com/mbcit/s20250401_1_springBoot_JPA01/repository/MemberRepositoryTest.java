package com.mbcit.s20250401_1_springBoot_JPA01.repository;

import java.time.LocalDateTime;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mbcit.s20250401_1_springBoot_JPA01.domain.Gender;
import com.mbcit.s20250401_1_springBoot_JPA01.domain.Member;

import lombok.extern.slf4j.Slf4j;

@Slf4j
//	@SpringBootTest 어노테이션은 springBoot에서 통합 테스트를 수행할 때 사용된다. 
//	전체 프로그램 컨텍스트를 로드하여 테스트를 실행할 수 있다.
@SpringBootTest
class MemberRepositoryTest {

	@Autowired
	private MemberRepository memberRepository;
	
	@Test
	void test() {
//		log.info("memberRepository : {}", memberRepository);
		log.info("MemberRepositoryTest 클래스의 test() 메서드 실행");
		
//		memberRepository.save(new Member(1L, "고길동", "a@a.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(2L, "엘사", "b@b.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(3L, "둘리", "c@c.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(4L, "뮬란", "d@d.com", LocalDateTime.now(), LocalDateTime.now()));
		
//		1줄 출력
		log.info("결과 : {}", memberRepository.findAll());
//		람다 식을 사용한 여러줄 출력
		memberRepository.findAll().forEach(System.out::println);
	}
	
	@Test
	public void insertAndUpdateTest() {
		System.out.println("MemberRepositoryTest 클래스의 insertAndUpdateTest() 메서드 실행");
		
//		@Column(updatable = false), @Column(insertable = false) 테스트
		System.out.println("@Column(updatable = false), @Column(insertable = false) 테스트");
		
		Member member = new Member();
		member.setName("머털도사");
		member.setEmail("mertel@m.com");
		member.setNickname("라해변!!");
		member.setCreateDate(LocalDateTime.now());
		member.setUpdateDate(LocalDateTime.now());
		memberRepository.save(member);	// insert
		
//		findById() : 특정 ID값을 기준으로 엔티티를 조회하는 기능을 실행한다.
//		orElse(null) : 데이터가 존재하면 엔티티 반환, 존재하지 않으면 null 반환 
		Member member2 = memberRepository.findById(5L).orElse(null);
		member2.setName("왕질악");
		// LocalDateTime.MAX => LocalDateTime의 최대값을 나타내는 상수.
//		member2.setCreateDate(LocalDateTime.MAX);
//		member2.setUpdateDate(LocalDateTime.MAX);
		memberRepository.save(member2);	// update
		
//		Spring Data JPA에서 모든 Member 엔티티를 조회한 후, forEach를 통해 각 엔티티를 출력하는 코드.
		memberRepository.findAll().forEach(System.out::println);
	}
	
	@Test
	public void enumTest() {
		System.out.println("MemberRepositoryTest 클래스의 enumTest() 메서드 실행");
		
		Member member = memberRepository.findById(5L).orElse(null);
		member.setGender(Gender.FEMALE);
		memberRepository.save(member);
		memberRepository.findAll().forEach(System.out::println);
		
		Map<String, Object> map = memberRepository.findRecord();
		for(String key : map.keySet()) {
			System.out.println(key + " : " + map.get(key));
		}
	}

}














