package com.mbcit.s20250401_1_springBoot_JPA01;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

//	@WebMvcTest : springBoot에서 MVC 컨트롤러를 테스트 하기 위해 사용하는 어노테이션. => 컨트롤러만 테스트 함.
//	=> 컨트롤러 관련 빈만 로드된다.
//	=> MockMVC를 사용해서 컨트롤러의 HTTP 요청 / 응답을 테스트 가능.
//	=> 컨트롤러가 올바르게 작동하는지 검증할 수 있다.
@WebMvcTest
class HomeControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@Test
	void testHome() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/"))
			.andDo(print())
			.andExpectAll(status().isOk());
			//.andExpect(content().string("springBoot JPA"));
	}

}
