package com.mbcit.s20250401_1_springBoot_JPA01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S202504011SpringBootJpa01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
