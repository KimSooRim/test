-- GenerationType 값에 상관없이 insert sql 명령실행
-- insert into member(id, name, email, create_date, update_date) values(1, '고길동', 'ko@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(2, '백설곤쥬', 'back@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(3, '둘리', 'dool@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(4, '배추도사', 'ba@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(5, '은비', 'eun@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(6, '까비', 'kka@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(7, '무도사', 'mu@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(8, '모아나', 'mo@1.com', now(), now());

-- GenerationType 값이 IDENTITY일 경우 insert sql 명령 실행
-- id 필드는 AUTO_INCREMENT가 자동으로 1씩 증가시켜 입력하므로 id 필드는 입력하지 않는다.
/*
insert into member(name, email, create_date, update_date) values('고길동', 'ko@1.com', now(), now());
insert into member(name, email, create_date, update_date) values('백설곤쥬', 'back@1.com', now(), now());
insert into member(name, email, create_date, update_date) values('둘리', 'dool@1.com', now(), now());
insert into member(name, email, create_date, update_date) values('배추도사', 'ba@1.com', now(), now());
insert into member(name, email, create_date, update_date) values('은비', 'eun@1.com', now(), now());
insert into member(name, email, create_date, update_date) values('까비', 'kka@1.com', now(), now());
insert into member(name, email, create_date, update_date) values('무도사', 'mu@1.com', now(), now());
insert into member(name, email, create_date, update_date) values('모아나', 'mo@1.com', now(), now());
*/

-- GenerationType 값이 SEQUENCE, TABLE, AUTO일 경우 insert sql 명령 실행
-- drop sequence member_id_seq;
-- create sequence member_id_seq start with 1 increment by 1;
-- insert into member(id, name, email, create_date, update_date) values(nextval('member_id_seq'), '고길동', 'ko@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(nextval('member_id_seq'), '백설곤쥬', 'back@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(nextval('member_id_seq'), '둘리', 'dool@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(nextval('member_id_seq'), '배추도사', 'ba@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(nextval('member_id_seq'), '은비', 'eun@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(nextval('member_id_seq'), '까비', 'kka@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(nextval('member_id_seq'), '무도사', 'mu@1.com', now(), now());
-- insert into member(id, name, email, create_date, update_date) values(nextval('member_id_seq'), '모아나', 'mo@1.com', now(), now());

-- @Table, @Column 어노테이션을 적용한 경우 insert sql 명령 실행
insert into member2(id, name,  nick, email, create_date, update_date) 
		values(nextval('member_id_seq'), '고길동', '고보살', 'ko@1.com', now(), now());
insert into member2(id, name,  nick, email, create_date, update_date) 
		values(nextval('member_id_seq'), '백설곤쥬', '곤쥬님', 'white@1.com', now(), now());
insert into member2(id, name, nick,  email, create_date, update_date) 
		values(nextval('member_id_seq'), '둘리', '사고뭉치', 'dooli@1.com', now(), now());
insert into member2(id, name, nick, email, create_date, update_date) 
		values(nextval('member_id_seq'), '배추도사', '이야기꾼1', 'baechu@1.com', now(), now());
insert into member2(id, name, nick, email, create_date, update_date) 
		values(nextval('member_id_seq'), '무도사', '이젤알도', 'moo@1.com', now(), now());




















